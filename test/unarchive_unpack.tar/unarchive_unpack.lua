module "unarchive"

unarchive.unpack [[
  src "test/unarchive_unpack.tar"
  dest "test/tmp"
]]
